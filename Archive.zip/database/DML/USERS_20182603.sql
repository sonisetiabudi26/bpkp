INSERT INTO users (PK_USER, USER_NAME, USER_PASSWORD, FK_LOOKUP_ROLE) VALUES
(1, 'cipta_ageung', 'R/fcaR5g1+n4vDJ3RxFrp5oA+5d7st2e9ewCbqOU3yo/iDMYEN6pXYFB37bJISbeE/wkWFdb9etOa/VAA2m9tg==', 2);
(2, 'soni_sb', 'CDkaHSZYVXUWH9uwCk7+ShWI/MR1BsZn+UIhdox4A2Q2wVlh7quSMqg9Bd5zVoZS/zvQDi8ZR4Z/fcWrhbjXbg==', 3);
